import{Link} from 'react-router-dom'
function Home(){
    return(
        <div>
            <h1>Pagina Home</h1>
            <Link to='/'>Home</Link><br/>
            <Link to='/cadastro'>Cadastro de Cliente</Link><br/>
            <Link to='/contacorrente'>Conta Corrente</Link><br/>
            <Link to='/financiamento'>Simulação de Financiamento</Link><br/>
            <Link to='/sobre'>Sobre Nós</Link>
        </div>
    )
}
export default Home;

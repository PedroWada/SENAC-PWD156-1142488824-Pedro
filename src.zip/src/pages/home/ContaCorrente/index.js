import{Link} from 'react-router-dom'
function ContaCorrente(){
    return(
        <div>
            <h1>Pagina Conta Corrente</h1>
            <Link to='/'>Home</Link><br/>
        </div>
    )
}
export default ContaCorrente;

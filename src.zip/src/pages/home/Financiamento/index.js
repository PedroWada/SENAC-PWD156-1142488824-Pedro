import{Link} from 'react-router-dom'
function Financiamento(){
    return(
        <div>
            <h1>Simulação de financiamento</h1>
            <Link to='/'>Home</Link><br/>
        </div>
    )
}
export default Financiamento;

import {BrowserRouter, Routes, Route}from 'react-router-dom';
import Home from './pages/home'
import Cadastro from './pages/home/Cadastro';
import ContaCorrente from './pages/home/ContaCorrente';
import Financiamento from './pages/home/Financiamento';
import Sobre from './pages/home/Sobre';
function RoutesApp(){
    return(
        <BrowserRouter>
            <Routes>    
                <Route path='/'element={<Home/>}></Route>
                <Route path='/cadastro'element={<Cadastro/>}></Route>
                <Route path='/contacorrente'element={<ContaCorrente/>}></Route>
                <Route path='/financiamento'element={<Financiamento/>}></Route>
                <Route path='/Sobre'element={<Sobre/>}></Route>
            </Routes>
        </BrowserRouter>
    )

}
export default RoutesApp;